// ゲームボードのキャンバスとコンテキストを取得
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
// 次のブロック表示用のキャンバスとコンテキストを取得
const nextPieceCanvas = document.getElementById('nextPieceCanvas');
const nextPieceCtx = nextPieceCanvas.getContext('2d');

// スコア表示要素
const scoreDisplay = document.getElementById('score');
const levelDisplay = document.getElementById('level');
const linesDisplay = document.getElementById('lines');
// ゲーム開始/リスタートボタン
const startButton = document.getElementById('startButton');
const restartButton = document.getElementById('restartButton');
// メッセージボックス
const messageBox = document.getElementById('messageBox');
const messageText = document.getElementById('messageText');
const messageBoxRestartButton = document.getElementById('messageBoxRestartButton');

// ゲームの定数
const COLS = 10; // 列数
const ROWS = 20; // 行数
const BLOCK_SIZE = 30; // 1ブロックのサイズ（ピクセル）
const EMPTY = 'white'; // 空のブロックの色（背景色）

// ゲームの状態変数
let board = []; // ゲームボード
let currentPiece; // 現在操作中のブロック
let nextPiece; // 次に落ちてくるブロック
let score = 0; // スコア
let level = 1; // レベル
let lines = 0; // 消したライン数
let dropInterval; // ブロックが落ちる間隔のタイマー
let dropSpeed = 1000; // ブロックが落ちる速度（ミリ秒）
let gameOver = false; // ゲームオーバーフラグ
let gameStarted = false; // ゲーム開始フラグ

// ブロックの形状と色を定義
const PIECES = [
    // I-ブロック (水色)
    {
        shape: [
            [0, 0, 0, 0],
            [1, 1, 1, 1],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ],
        color: '#00FFFF'
    },
    // J-ブロック (青)
    {
        shape: [
            [1, 0, 0],
            [1, 1, 1],
            [0, 0, 0]
        ],
        color: '#0000FF'
    },
    // L-ブロック (オレンジ)
    {
        shape: [
            [0, 0, 1],
            [1, 1, 1],
            [0, 0, 0]
        ],
        color: '#FFA500'
    },
    // O-ブロック (黄色)
    {
        shape: [
            [1, 1],
            [1, 1]
        ],
        color: '#FFFF00'
    },
    // S-ブロック (緑)
    {
        shape: [
            [0, 1, 1],
            [1, 1, 0],
            [0, 0, 0]
        ],
        color: '#008000'
    },
    // T-ブロック (紫)
    {
        shape: [
            [0, 1, 0],
            [1, 1, 1],
            [0, 0, 0]
        ],
        color: '#800080'
    },
    // Z-ブロック (赤)
    {
        shape: [
            [1, 1, 0],
            [0, 1, 1],
            [0, 0, 0]
        ],
        color: '#FF0000'
    }
];

/**
 * ゲームボードを初期化する関数
 */
function initBoard() {
    board = Array(ROWS).fill(0).map(() => Array(COLS).fill(EMPTY));
}

/**
 * 新しいブロックを生成する関数
 * @returns {object} 新しいブロックのオブジェクト
 */
function createPiece() {
    const randomPiece = PIECES[Math.floor(Math.random() * PIECES.length)];
    return {
        shape: randomPiece.shape,
        color: randomPiece.color,
        x: Math.floor(COLS / 2) - Math.floor(randomPiece.shape[0].length / 2), // 中央に配置
        y: 0 // 上から降ってくる
    };
}

/**
 * 1つのブロックを描画する関数
 * @param {number} x - ブロックのX座標（グリッド単位）
 * @param {number} y - ブロックのY座標（グリッド単位）
 * @param {string} color - ブロックの色
 * @param {CanvasRenderingContext2D} context - 描画するキャンバスのコンテキスト
 */
function drawBlock(x, y, color, context) {
    context.fillStyle = color;
    context.fillRect(x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
    context.strokeStyle = '#333'; // ブロックの境界線
    context.lineWidth = 1;
    context.strokeRect(x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
}

/**
 * ゲームボード全体を描画する関数
 */
function drawBoard() {
    for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
            drawBlock(c, r, board[r][c], ctx);
        }
    }
}

/**
 * 現在のブロックを描画する関数
 * @param {object} piece - 描画するブロックのオブジェクト
 * @param {CanvasRenderingContext2D} context - 描画するキャンバスのコンテキスト
 * @param {number} offsetX - X座標のオフセット（次のブロック表示用）
 * @param {number} offsetY - Y座標のオフセット（次のブロック表示用）
 */
function drawPiece(piece, context, offsetX = 0, offsetY = 0) {
    for (let r = 0; r < piece.shape.length; r++) {
        for (let c = 0; c < piece.shape[r].length; c++) {
            if (piece.shape[r][c]) {
                drawBlock(piece.x + c + offsetX, piece.y + r + offsetY, piece.color, context);
            }
        }
    }
}

/**
 * 次のブロック表示キャンバスをクリアし、次のブロックを描画する関数
 */
function drawNextPiece() {
    nextPieceCtx.clearRect(0, 0, nextPieceCanvas.width, nextPieceCanvas.height);
    // 次のブロックを中央に配置するためのオフセットを計算
    const pieceWidth = nextPiece.shape[0].length;
    const pieceHeight = nextPiece.shape.length;
    const centerOffsetX = (nextPieceCanvas.width / BLOCK_SIZE - pieceWidth) / 2;
    const centerOffsetY = (nextPieceCanvas.height / BLOCK_SIZE - pieceHeight) / 2;

    drawPiece(nextPiece, nextPieceCtx, centerOffsetX, centerOffsetY);
}

/**
 * 衝突判定を行う関数
 * @param {number} x - 移動先のX座標
 * @param {number} y - 移動先のY座標
 * @param {Array<Array<number>>} shape - 判定するブロックの形状
 * @returns {boolean} 衝突していればtrue、していなければfalse
 */
function collision(x, y, shape) {
    for (let r = 0; r < shape.length; r++) {
        for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c]) {
                const newX = x + c;
                const newY = y + r;

                // ボードの境界線との衝突判定
                if (newX < 0 || newX >= COLS || newY >= ROWS) {
                    return true;
                }
                // ボード内の他のブロックとの衝突判定（Y座標が0未満の場合は無視）
                if (newY >= 0 && board[newY][newX] !== EMPTY) {
                    return true;
                }
            }
        }
    }
    return false;
}

/**
 * ブロックをボードに固定する関数
 */
function lockPiece() {
    for (let r = 0; r < currentPiece.shape.length; r++) {
        for (let c = 0; c < currentPiece.shape[r].length; c++) {
            if (currentPiece.shape[r][c]) {
                // Y座標が0未満の場合はゲームオーバー
                if (currentPiece.y + r < 0) {
                    setGameOver();
                    return;
                }
                board[currentPiece.y + r][currentPiece.x + c] = currentPiece.color;
            }
        }
    }
    clearLines(); // ライン消去をチェック
    spawnNewPiece(); // 新しいブロックを生成
}

/**
 * ライン消去をチェックし、スコアを更新する関数
 */
function clearLines() {
    let linesCleared = 0;
    for (let r = ROWS - 1; r >= 0; r--) {
        // 行が全て埋まっているかチェック
        if (board[r].every(cell => cell !== EMPTY)) {
            linesCleared++;
            // その行を削除し、新しい空の行を一番上に追加
            board.splice(r, 1);
            board.unshift(Array(COLS).fill(EMPTY));
            r++; // 削除した行の分、再度同じ行をチェック
        }
    }

    if (linesCleared > 0) {
        // スコア計算 (テトリス公式ルールに準拠)
        const scoreMultiplier = [0, 100, 300, 500, 800]; // 1, 2, 3, 4ライン消去時のスコア
        score += scoreMultiplier[linesCleared] * level;
        lines += linesCleared;

        // レベルアップの判定
        if (lines >= level * 10) { // 10ラインごとにレベルアップ
            level++;
            dropSpeed = Math.max(50, dropSpeed - 50); // 速度を上げる（最低50ms）
            clearInterval(dropInterval);
            dropInterval = setInterval(drop, dropSpeed);
        }

        updateScoreDisplay();
    }
}

/**
 * スコア、レベル、ライン表示を更新する関数
 */
function updateScoreDisplay() {
    scoreDisplay.textContent = score;
    levelDisplay.textContent = level;
    linesDisplay.textContent = lines;
}

/**
 * ブロックを回転させる関数
 * @param {Array<Array<number>>} shape - 回転させるブロックの形状
 * @returns {Array<Array<number>>} 回転後の形状
 */
function rotate(shape) {
    // 行と列を入れ替えて転置し、各行を反転させる
    const newShape = shape[0].map((_, c) => shape.map(row => row[c])).reverse();
    return newShape;
}

/**
 * ブロックを下に落とす関数
 */
function drop() {
    if (gameOver || !gameStarted) return;

    if (!collision(currentPiece.x, currentPiece.y + 1, currentPiece.shape)) {
        currentPiece.y++;
    } else {
        lockPiece();
    }
    draw();
}

/**
 * ブロックをハードドロップする関数（一番下まで一気に落とす）
 */
function hardDrop() {
    if (gameOver || !gameStarted) return;

    while (!collision(currentPiece.x, currentPiece.y + 1, currentPiece.shape)) {
        currentPiece.y++;
        score += 2; // ハードドロップのスコア
    }
    lockPiece();
    draw();
    updateScoreDisplay();
}

/**
 * ゲームオーバー時の処理
 */
function setGameOver() {
    gameOver = true;
    clearInterval(dropInterval);
    messageText.textContent = `ゲームオーバー！スコア: ${score}`;
    messageBox.style.display = 'block';
    startButton.style.display = 'none';
    restartButton.style.display = 'block';
}

/**
 * 新しいブロックを生成し、ゲームオーバーをチェックする関数
 */
function spawnNewPiece() {
    currentPiece = nextPiece;
    nextPiece = createPiece();
    drawNextPiece();
    if (collision(currentPiece.x, currentPiece.y, currentPiece.shape)) {
        setGameOver();
    }
}

/**
 * 全体を再描画する関数
 */
function draw() {
    // キャンバスをクリア
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBoard(); // ボードを描画
    if (!gameOver) {
        drawPiece(currentPiece, ctx); // 現在のブロックを描画
    }
}

/**
 * ゲームを初期化する関数
 */
function initGame() {
    initBoard();
    score = 0;
    level = 1;
    lines = 0;
    dropSpeed = 1000;
    gameOver = false;
    gameStarted = false; // ゲーム開始ボタンを押すまでfalse
    updateScoreDisplay();
    messageBox.style.display = 'none'; // メッセージボックスを非表示に
    startButton.style.display = 'block'; // 開始ボタンを表示
    restartButton.style.display = 'none'; // リスタートボタンを非表示
    // 最初のブロックを生成
    nextPiece = createPiece(); // 最初のnextPieceを生成
    currentPiece = createPiece(); // 最初のcurrentPieceを生成
    drawNextPiece(); // 次のブロック表示を更新
    draw(); // 初期ボードを描画
}

/**
 * ゲームを開始する関数
 */
function startGame() {
    if (gameStarted) return; // 既に開始している場合は何もしない
    gameStarted = true;
    startButton.style.display = 'none';
    restartButton.style.display = 'block';
    spawnNewPiece(); // 最初のブロックをボードに配置
    dropInterval = setInterval(drop, dropSpeed); // ブロックの落下を開始
    draw();
}

/**
 * ゲームをリスタートする関数
 */
function restartGame() {
    clearInterval(dropInterval); // 既存のタイマーをクリア
    initGame(); // ゲームの状態をリセット
    startGame(); // ゲームを再開
}

// イベントリスナーの設定

// キーボード操作
document.addEventListener('keydown', e => {
    if (gameOver || !gameStarted) return;

    let moved = false;
    switch (e.key) {
        case 'ArrowLeft':
            if (!collision(currentPiece.x - 1, currentPiece.y, currentPiece.shape)) {
                currentPiece.x--;
                moved = true;
            }
            break;
        case 'ArrowRight':
            if (!collision(currentPiece.x + 1, currentPiece.y, currentPiece.shape)) {
                currentPiece.x++;
                moved = true;
            }
            break;
        case 'ArrowDown':
            if (!collision(currentPiece.x, currentPiece.y + 1, currentPiece.shape)) {
                currentPiece.y++;
                score += 1; // ソフトドロップのスコア
                updateScoreDisplay();
                moved = true;
            }
            break;
        case 'ArrowUp':
            const rotatedShape = rotate(currentPiece.shape);
            if (!collision(currentPiece.x, currentPiece.y, rotatedShape)) {
                currentPiece.shape = rotatedShape;
                moved = true;
            }
            break;
        case ' ': // スペースキー
            e.preventDefault(); // ページスクロールを防ぐ
            hardDrop();
            moved = true;
            break;
    }
    if (moved) {
        draw();
    }
});

// ボタン操作
document.getElementById('leftButton').addEventListener('click', () => {
    if (gameOver || !gameStarted) return;
    if (!collision(currentPiece.x - 1, currentPiece.y, currentPiece.shape)) {
        currentPiece.x--;
        draw();
    }
});

document.getElementById('rightButton').addEventListener('click', () => {
    if (gameOver || !gameStarted) return;
    if (!collision(currentPiece.x + 1, currentPiece.y, currentPiece.shape)) {
        currentPiece.x++;
        draw();
    }
});

document.getElementById('rotateButton').addEventListener('click', () => {
    if (gameOver || !gameStarted) return;
    const rotatedShape = rotate(currentPiece.shape);
    if (!collision(currentPiece.x, currentPiece.y, rotatedShape)) {
        currentPiece.shape = rotatedShape;
        draw();
    }
});

document.getElementById('downButton').addEventListener('click', () => {
    if (gameOver || !gameStarted) return;
    if (!collision(currentPiece.x, currentPiece.y + 1, currentPiece.shape)) {
        currentPiece.y++;
        score += 1;
        updateScoreDisplay();
        draw();
    }
});

document.getElementById('dropButton').addEventListener('click', hardDrop);

startButton.addEventListener('click', startGame);
restartButton.addEventListener('click', restartGame);
messageBoxRestartButton.addEventListener('click', restartGame);

// ページロード時にゲームを初期化
window.onload = initGame;
